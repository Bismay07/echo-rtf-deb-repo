#!/bin/bash

# If uuidgen isn't installed
if ! command -v uuidgen >/dev/null 2>&1; then
    apt update && apt install -y uuid-runtime
fi

# Generate a randomized flag
FLAG="FLAG{$(uuidgen | cut -d- -f1)}"

# Save the secret answer for validation (root-only readable)
mkdir -p /var/lib/rtf/echo-rtf-1
echo "$FLAG" > /var/lib/rtf/echo-rtf-1/.secret.flag
chmod 600 /var/lib/rtf/echo-rtf-1/.secret.flag
chown root:root /var/lib/rtf/echo-rtf-1/.secret.flag


# Create a deep folder structure and hide the flag
mkdir -p /opt/rtf/hiddenlab/layer1/layer2/layer3
echo "$FLAG" > /opt/rtf/hiddenlab/layer1/layer2/layer3/.hiddenflag.txt
chmod 600 /opt/rtf/hiddenlab/layer1/layer2/layer3/.hiddenflag.txt
chown root:root /opt/rtf/hiddenlab/layer1/layer2/layer3/.hiddenflag.txt

