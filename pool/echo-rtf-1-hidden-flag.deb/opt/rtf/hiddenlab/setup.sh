#!/bin/bash

# Generate a randomized flag
FLAG="FLAG{$(uuidgen | cut -d- -f1)}"

# Save the secret answer for validation (root-only readable)
echo "$FLAG" > /opt/rtf/hiddenlab/.secret.flag
chmod 600 /opt/rtf/hiddenlab/.secret.flag
chown root:root /opt/rtf/hiddenlab/.secret.flag

# Create a deep folder structure and hide the flag
mkdir -p /opt/rtf/hiddenlab/layer1/layer2/layer3
echo "$FLAG" > /opt/rtf/hiddenlab/layer1/layer2/layer3/.hiddenflag.txt
chmod 600 /opt/rtf/hiddenlab/layer1/layer2/layer3/.hiddenflag.txt
chown root:root /opt/rtf/hiddenlab/layer1/layer2/layer3/.hiddenflag.txt

